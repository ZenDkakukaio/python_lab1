# coding: utf-8

from pysnmp.hlapi import *
from pysnmp.entity.rfc3413.oneliner import cmdgen
import sqlite3

# script qui va recuperer les informations sur le materiel, les constructeurs, l'Ios de l'equipement

port = 161


def define_ip_address():
    print("entrer l'adresse ip de l'equipement si vous voulez recuperer des donnees sur le materiel, le systeme de l'equipement :")
    ip_address_router = input(">  ")

    return ip_address_router


def define_community():
    print("entrer la communaute: ")
    community = input(">  ")

    return community


def get_data_material_constructor_ios():
    data = []
    cmdGen = cmdgen.CommandGenerator()
    errorIndication, errorStatus, errorindex, varBinds = cmdGen.getCmd(
        # SnmpEngine(),
        CommunityData(define_community()),
        UdpTransportTarget((define_ip_address(), port)),

        ObjectIdentity('iso.3.6.1.2.1.47.1.1.1.1.2.65536'),
        ObjectIdentity('iso.3.6.1.2.1.47.1.1.1.1.2.131073'),
        ObjectIdentity('iso.3.6.1.2.1.47.1.1.1.1.2.131074'),
        ObjectIdentity('iso.3.6.1.2.1.47.1.1.1.1.2.131075'),
        ObjectIdentity('iso.3.6.1.2.1.47.1.1.1.1.2.131076'),
        ObjectIdentity('iso.3.6.1.2.1.47.1.1.1.1.2.131077'),
        ObjectIdentity('iso.3.6.1.2.1.47.1.1.1.1.2.131078'),
        ObjectIdentity('iso.3.6.1.2.1.47.1.1.1.1.2.131079'),
        ObjectIdentity('iso.3.6.1.2.1.47.1.1.1.1.2.131080'),
        ObjectIdentity('iso.3.6.1.2.1.47.1.1.1.1.2.131081'),
        ObjectIdentity('iso.3.6.1.2.1.47.1.1.1.1.2.131082'),
        ObjectIdentity('iso.3.6.1.2.1.47.1.1.1.1.2.131083'),


        lookupNames=True, lookupValues=True,

    )

    if errorIndication:
        print(f"[ErrorIndication] de type {errorIndication}")

    elif errorStatus:
        print(f"[ErrorStatus] de type {errorStatus}")

    elif errorindex:
        print(f"[ErrorIndex] de type {errorindex}")

    else:

        for name, value in varBinds:
            data.append({'nom': name.prettyPrint(), 'valeur': value.prettyPrint()})

            base_name = name.prettyPrint()
            base_value = value.prettyPrint()

            print(f"{base_name}----->{base_value}")

            construct_router_value = str(base_value)
            construct_router_name = str(base_name)

            print(f"{construct_router_name}----->{construct_router_value}")



            print(f"{construct_router_value}")


            print(f"{construct_router_value}")



            database_fnct(construct_router_name, construct_router_value)


def database_fnct(name="core", value="value"):
    try:

        conn = sqlite3.connect("data_mib.sqlite3")
        database_cursor = conn.cursor()
        database_cursor.execute("""

            CREATE TABLE IF NOT EXISTS mikrotik_construct(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
             name TEXT,
             construct TEXT

            )  

        """)
        conn.commit()

        db_mikrotik = (name, value)

        database_cursor.execute('INSERT INTO mikrotik_construct(name, construct) VALUES(?,?)', db_mikrotik)

        conn.commit()

    except Exception as e:
        print(f"[erreur de type]: {e}")

        conn.rollback()


    finally:
        conn.close()


get_data_material_constructor_ios()


