# coding: utf-8

from pysnmp.hlapi import *
from pysnmp.entity.rfc3413.oneliner import cmdgen
import sqlite3



port = 161

#script qui va recuperer d'autres donnees du reseaux  de l'equipement

def define_ip_address():
    print("entrer l'adresse ip de l'equipement si vous voulez recuperer des donnees concernant les parametres reseaux de l'equipement:")
    ip_address_router = input(">  ")

    return ip_address_router


def get_data_other_network():
    data = []
    cmdGen = cmdgen.CommandGenerator()
    errorIndication, errorStatus, errorindex, varBinds = cmdGen.getCmd(
        # SnmpEngine(),
        CommunityData('public'),
        UdpTransportTarget((define_ip_address(), port)),

        ObjectIdentity('iso.3.6.1.2.1.4.20.1.1.192.168.1.3'),

        ObjectIdentity('iso.3.6.1.2.1.4.20.1.2.192.168.1.3'),

        ObjectIdentity('iso.3.6.1.2.1.4.20.1.3.192.168.1.3'),

        ObjectIdentity('iso.3.6.1.2.1.4.20.1.4.192.168.1.3'),


        lookupNames=True, lookupValues=True,

    )

    if errorIndication:
        print(f"erreur de type {errorIndication}")

    elif errorStatus:
        print(f"erreur de type {errorStatus}")

    elif errorindex:
        print(f"erreur de type {errorindex}")

    else:

        for name, value in varBinds:
            data.append({'nom': name.prettyPrint(), 'valeur': value.prettyPrint()})

            base_name = name.prettyPrint()
            base_value = value.prettyPrint()

            print(f"{base_name}----->{base_value}")

            other_network_value = str(base_value)
            other_network_name = str(base_name)

            print(f"{other_network_name}----->{other_network_value}")



            print(f"{other_network_value}")


            print(f"{other_network_name}")



            database_fnct(other_network_name, other_network_value)


def database_fnct(name="core", value="value"):
    try:

        conn = sqlite3.connect("data_mib.sqlite3")
        database_cursor = conn.cursor()
        database_cursor.execute("""

            CREATE TABLE IF NOT EXISTS mikrotik_other_network(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
             name TEXT,
             other_network INTEGER

            )  

        """)
        conn.commit()

        db_mikrotik = (name, value)

        database_cursor.execute('INSERT INTO mikrotik_other_network(name, other_network) VALUES(?,?)', db_mikrotik)

        conn.commit()

    except Exception as e:
        print(f"[erreur de type]: {e}")

        conn.rollback()


    finally:
        conn.close()


get_data_other_network()


