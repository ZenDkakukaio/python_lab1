#coding: utf-8

from pysnmp.hlapi import *
from pysnmp.entity.rfc3413.oneliner import cmdgen
import sqlite3



#script qui va recuperer les informations de capacites de la memoire interne du routeur mikrotik

port = 161


def define_ip_address():

    print("entrer l'adresse ip de l'equipement pour recuperer la capacite memoire de l'equipement:")
    ip_address_router = input(">  ")

    return ip_address_router



def define_community():
    print("entrer la communaute: ")
    community = input(">  ")

    return community




def get_data_capacity():

    data = []
    cmdGen = cmdgen.CommandGenerator()
    errorIndication, errorStatus, errorindex, varBinds = cmdGen.getCmd(
        #SnmpEngine(),
        CommunityData(define_community()),
        UdpTransportTarget((define_ip_address(), port)),

        (ObjectIdentity('iso.3.6.1.2.1.25.2.3.1.5.131072')),




    lookupNames=True, lookupValues=True,

    )

    if errorIndication:
        print(f"[ErrorIndication] de type {errorIndication}")

    elif errorStatus:
        print(f"[ErrorStatus] de type {errorStatus}")

    elif errorindex:
        print(f"[ErrorIndex] de type {errorindex}")

    else:

        for name, value in varBinds:
            data.append({'nom': name.prettyPrint(), 'valeur': value.prettyPrint()})


            base_name = name.prettyPrint()
            base_value = value.prettyPrint()


            print(f"{base_name}----->{base_value}")

            space_disk_router_value = int(base_value)
            space_disk_router_name = str(base_name)

            print(f"{space_disk_router_name}----->{space_disk_router_value}")





            if space_disk_router_value < 2000:

                print(f"la capacite de votre disque:{space_disk_router_value} Bits est tres faible, alerte rouge")

            elif space_disk_router_value > 2000:
                print(f"la capacite de votre disque:{space_disk_router_value} Bits est en bonne etat")

            else:
                print("RAS")

        database_fnct(space_disk_router_name, space_disk_router_value)


def database_fnct(name="core", value=5):
    try:

        conn = sqlite3.connect("data_mib.sqlite3")
        database_cursor = conn.cursor()
        database_cursor.execute("""

            CREATE TABLE IF NOT EXISTS mikrotik(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
             name TEXT,
            capacity_disk INTEGER
           
            )  

        """)
        conn.commit()

        db_mikrotik = (name, value)

        database_cursor.execute('INSERT INTO mikrotik(name, capacity_disk) VALUES(?,?)', db_mikrotik)

        conn.commit()

    except Exception as e:
        print(f"[erreur de type]: {e}")

        conn.rollback()


    finally:
        conn.close()


get_data_capacity()


