#coding: utf-8


import secure_lab_get_capacity_router
import secure_lab_get_material_equipement
import secure_memory_disk_equipement
import secure_get_network_interface
import secure_get_other_network
import threading
import time
from datetime import date
from tkinter import *


delay = time.sleep(5)

#definition de la classe Admin


class action_admin:
    def __init__(self, name_admin="admin"):
        self.name_admin = name_admin


    def call_admin(self):

        name = input("Entrer votre nom > ")
        print(f"Merci {name} d'avoir tester le programme :)")

        return name



    def call_capacity_router(self):

        return secure_lab_get_capacity_router


    def call_material_construct_equipement(self):

        return secure_lab_get_material_equipement


    def call_memory_equipement(self):
        return secure_memory_disk_equipement

    def call_network_equipement(self):
        return secure_get_network_interface

    def call_other_network_equipement(self):
        return secure_get_other_network

    def admin_time_now(self):
        name_time_now = date.today()

        return name_time_now





class my_process(threading.Thread):
    def __init__(self, admin):
        self.admin = admin
        threading.Thread.__init__(self)

    def run(self):
        i = 0

        while i < 5:
            print(threading.current_thread())
            time.sleep(1)
            i += 1

admin = action_admin()

#creation des processing
th1 = my_process(admin.call_admin())
th2 = my_process(admin.call_capacity_router())
th3 = my_process(admin.call_material_construct_equipement())
th4 = my_process(admin.call_memory_equipement())
th5 = my_process(admin.call_network_equipement())
th6 = my_process(admin.call_other_network_equipement())

th1.start()
time.sleep(2)
th2.start()
th3.start()
time.sleep(2)
th4.start()
time.sleep(2)
th5.start()
time.sleep(2)
th6.start()
time.sleep(2)

th1.join()
th2.join()
th3.join()
th4.join()
th5.join()
th6.join()

print("FIN DU PROGRAMME :)")
admin.admin_time_now()



######### CONSTRUCTION DE L'INTERFACE GRAFIQUE #########################




















