# coding: utf-8

from pysnmp.hlapi import *
from pysnmp.entity.rfc3413.oneliner import cmdgen
import sqlite3



port = 161

#script qui va recuperer les donnees de la memoire RAM et autres memoire de l'equipement

def define_ip_address():
    print("entrer l'adresse ip de l'equipement si vous voulez recuperer des donnees sur les memoires de l'equipement:")
    ip_address_router = input(">  ")

    return ip_address_router


def define_community():
    print("entrer la communaute: ")
    community = input(">  ")

    return community


def get_data_memory():
    data = []
    cmdGen = cmdgen.CommandGenerator()
    errorIndication, errorStatus, errorindex, varBinds = cmdGen.getCmd(
        # SnmpEngine(),
        CommunityData(define_community()),
        UdpTransportTarget((define_ip_address(), port)),

        ObjectIdentity('iso.3.6.1.2.1.47.1.1.1.1.7.65536'),
        ObjectIdentity('iso.3.6.1.2.1.25.2.3.1.3.65536'),
        ObjectIdentity('iso.3.6.1.2.1.25.2.3.1.3.131072'),
        ObjectIdentity('iso.3.6.1.2.1.25.2.3.1.4.65536'),
        ObjectIdentity('iso.3.6.1.2.1.25.2.3.1.4.131072'),
        ObjectIdentity('iso.3.6.1.2.1.25.2.3.1.5.131072'),      #espace disk total hdd
        ObjectIdentity('iso.3.6.1.2.1.25.2.3.1.6.131072'),       #espace disk utilisee hdd
        ObjectIdentity('.1.3.6.1.2.1.25.2.3.1.6.65536'),           #memoire ram utilisee
        ObjectIdentity('.1.3.6.1.2.1.25.2.3.1.5.65536'),  # memoire ram totale
        ObjectIdentity('.1.3.6.1.4.1.14988.1.1.7.6.0'),  # buildtime
        #ObjectIdentity('.1.3.6.1.4.1.14988.1.1.3.1.4.0'),  # frequence du cpu
        ObjectIdentity('.1.3.6.1.2.1.25.3.3.1.2.1'),  # charge du cpu
        ObjectIdentity('.1.3.6.1.2.1.1.3.0'),                 #uptime





        lookupNames=True, lookupValues=True,

    )

    if errorIndication:
        print(f"[ErrorIndication] de type {errorIndication}")

    elif errorStatus:
        print(f"[ErrorStatus] de type {errorStatus}")

    elif errorindex:
        print(f"[ErrorIndex] de type {errorindex}")

    else:

        for name, value in varBinds:
            data.append({'nom': name.prettyPrint(), 'valeur': value.prettyPrint()})

            base_name = name.prettyPrint()
            base_value = value.prettyPrint()

            print(f"{base_name}----->{base_value}")

            memory_routor_value = str(base_value)
            memory_routor_name = str(base_name)

            print(f"{memory_routor_name}----->{memory_routor_value}")



            print(f"{memory_routor_value}")


            print(f"{memory_routor_name}")



            database_fnct(memory_routor_name, memory_routor_value)


def database_fnct(name="core", value="value"):
    try:

        conn = sqlite3.connect("data_mib.sqlite3")
        database_cursor = conn.cursor()
        database_cursor.execute("""

            CREATE TABLE IF NOT EXISTS mikrotik_memory(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
             name TEXT,
             memory INTEGER

            )  

        """)
        conn.commit()

        db_mikrotik = (name, value)

        database_cursor.execute('INSERT INTO mikrotik_memory(name, memory) VALUES(?,?)', db_mikrotik)

        conn.commit()

    except Exception as e:
        print(f"[erreur de type]: {e}")

        conn.rollback()


    finally:
        conn.close()


get_data_memory()


