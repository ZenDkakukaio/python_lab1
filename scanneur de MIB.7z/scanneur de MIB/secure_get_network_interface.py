# coding: utf-8

from pysnmp.hlapi import *
from pysnmp.entity.rfc3413.oneliner import cmdgen
import sqlite3



port = 161

#script qui va recuperer les donnees reseaux de l'equipement

def define_ip_address():
    print("entrer l'adresse ip de l'equipement si vous voulez recuperer d'autres donnees sur l'interface reseaux de l'equipement:")
    ip_address_router = input(">  ")

    return ip_address_router


def define_community():
    print("entrer la communaute: ")
    community = input(">  ")

    return community


def get_data_network():
    data = []
    cmdGen = cmdgen.CommandGenerator()
    errorIndication, errorStatus, errorindex, varBinds = cmdGen.getCmd(
        # SnmpEngine(),
        CommunityData(define_community()),
        UdpTransportTarget((define_ip_address(), port)),

        ObjectIdentity('.1.3.6.1.2.1.2.2.1.2.1'),
        ObjectIdentity('.1.3.6.1.2.1.2.2.1.4.1'),
        ObjectIdentity('.1.3.6.1.2.1.2.2.1.6.1'),
        ObjectIdentity('.1.3.6.1.2.1.2.2.1.7.1'),
        ObjectIdentity('.1.3.6.1.2.1.2.2.1.8.1'),
        ObjectIdentity('.1.3.6.1.2.1.31.1.1.1.6.1'),
        ObjectIdentity('.1.3.6.1.2.1.31.1.1.1.7.1'),
        ObjectIdentity('.1.3.6.1.2.1.2.2.1.13.1'),
        ObjectIdentity('.1.3.6.1.2.1.2.2.1.14.1'),
        ObjectIdentity('.1.3.6.1.2.1.31.1.1.1.10.1'),
        ObjectIdentity('.1.3.6.1.2.1.31.1.1.1.11.1'),
        ObjectIdentity('.1.3.6.1.2.1.2.2.1.19.1'),
        ObjectIdentity('.1.3.6.1.2.1.2.2.1.20.1'),

        lookupNames=True, lookupValues=True,

    )

    if errorIndication:
        print(f"[ErrorIndication] de type {errorIndication}")

    elif errorStatus:
        print(f"[ErrorStatus] de type {errorStatus}")

    elif errorindex:
        print(f"[ErrorIndex] de type {errorindex}")

    else:

        for name, value in varBinds:
            data.append({'nom': name.prettyPrint(), 'valeur': value.prettyPrint()})

            base_name = name.prettyPrint()
            base_value = value.prettyPrint()

            print(f"{base_name}----->{base_value}")

            network_value = str(base_value)
            network_name = str(base_name)

            print(f"{network_name}----->{network_value}")



            print(f"{network_value}")


            print(f"{network_name}")



            database_fnct(network_name, network_value)


def database_fnct(name="core", value="value"):
    try:

        conn = sqlite3.connect("data_mib.sqlite3")
        database_cursor = conn.cursor()
        database_cursor.execute("""

            CREATE TABLE IF NOT EXISTS mikrotik_network(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
             name TEXT,
             network INTEGER

            )  

        """)
        conn.commit()

        db_mikrotik = (name, value)

        database_cursor.execute('INSERT INTO mikrotik_network(name, network) VALUES(?,?)', db_mikrotik)

        conn.commit()

    except Exception as e:
        print(f"[erreur de type]: {e}")

        conn.rollback()


    finally:
        conn.close()


get_data_network()


