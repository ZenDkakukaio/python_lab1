
from kivymd.app import MDApp
from kivy.lang.builder import Builder
from layout import MyLayout
from kivy.config import Config

Config.set('kivy', 'window_icon', 'ZenSearch_project/media/img/logo.png')





class MyApp(MDApp):
    icon = 'ZenSearch_project/media/img/logo.png'
    def __init__(self):
        super(MyApp, self).__init__()


    def build(self):
        self.title = "Zen-Search"
        self.load_all_file_kv()
        #self.theme_cls.theme_style = "Dark"
        return MyLayout()

    def load_all_file_kv(self):
        Builder.load_file("layout.kv")




if __name__ == '__main__':
    obj = MyApp()
    obj.run()