from kivymd.uix.screen import MDScreen
from kivy.core.clipboard import Clipboard
from kivymd.uix.button import MDFlatButton,\
    MDRectangleFlatButton
from kivymd.uix.dialog import MDDialog
from kivymd.uix.list import OneLineListItem
from kivy.core.window import Window
from kivymd.uix.menu import MDDropdownMenu
from kivymd.uix.bottomsheet import MDGridBottomSheet
from kivymd.uix.picker import MDThemePicker
from kivymd.toast import toast
from kivymd.app import MDApp



import wikipedia
import threading
import json as jso

Window.size = (370, 650)
obj = MDApp()

with open("C:/env_repository/venv5_icon/ZenSearch_project/media/json file/f.json") as f:
    data = jso.load(f)


class MyLayout(MDScreen):
    url = ""
    data_target = data["image_logo"]["avatar"]

    def __init__(self):
        super(MyLayout, self).__init__()

    def search(self, text):
        t1 = threading.Thread(target=self.get_wiki, args=(text,))
        t1.start()

    def get_wiki(self, text):
        self.ids.rc_spin.active = True
        self.ids.summary.text = ""
        self.ids.title.text = ""
        self.ids.error.text = ""


        try:
            summary = wikipedia.page(text.strip())
            self.ids.title.text = summary.title
            self.ids.summary.text = f"\n{summary.summary}"
        except Exception as e:
            toast(e)
            self.ids.summary.text = (
                toast("désolé erreur lors de la recherche " + self.ids.fls.text)
            )
        self.ids.rc_spin.active = False


    def open_menu(self):

        d = ["Langue", "theme", "Quitter"]
        menu_items = [
            {
                "text": f"{i}-{d[i]}",
                "viewclass": "OneLineListItem",
                "on_release": lambda x=f"{d[i]}": self.menu_callback(x)

            }for i in range(len(d))
        ]
        self.menu = MDDropdownMenu(
            caller=self.ids.id_button_menu,
            items=menu_items,
            width_mult = 4,
        )
        self.menu.open()

    def menu_callback(self, text_item_x):

        if text_item_x == "Langue":
            self.show_language()


        elif text_item_x == "theme":
            self.show_theme()

        elif text_item_x == "Quitter":
            obj.stop()



    def show_language(self):

        bottom_sheet_menu = MDGridBottomSheet()
        data_language = {
            "Fr": "flag-variant",
            "En": "flag-variant",

        }
        for item in data_language.items():
            bottom_sheet_menu.add_item(

                    item[0],
                    lambda y=item[0], x=item[0]: self.choise_language(y, x),
                    icon_src=item[1],

                )
            bottom_sheet_menu.open()


    def show_theme(self):
        theme = MDThemePicker()
        theme.open()
        return toast("Theme de l'application")

    def choise_language(self, item_language, item_keys_language):
        if item_keys_language == "Fr":
            self.switch_fr()
            toast("Langue selectionnée: Français")
        elif item_keys_language == "En":
            self.switch_en()
            toast("Langue selectionnée: Anglais")


        else:
            return toast("Erreur lors du chargement de la langue")

    def switch_fr(self):
        wikipedia.set_lang("fr")

    def switch_en(self):
        wikipedia.set_lang("en")