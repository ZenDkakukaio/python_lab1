from kivymd.utils.fitimage import FitImage



class MyAvatar(FitImage):
    pass